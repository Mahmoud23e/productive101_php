<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Allow-Headers: Content-Type");

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $data = json_decode(file_get_contents("php://input"), true);
    $tid = $data['tid'];

    $stmt = $conn->prepare("DELETE FROM tasks WHERE tid = ?");
    $stmt->bind_param("i", $tid);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Task deleted successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error deleting task"]);
    }

    $stmt->close();
    $conn->close();
}
?>
