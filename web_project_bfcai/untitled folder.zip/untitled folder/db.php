<?php
$host = 'localhost';
$user = 'root'; // اسم المستخدم
$password = ''; // كلمة المرور
$database = 'ToDoList';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
